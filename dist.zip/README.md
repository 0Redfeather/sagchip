# hello-world
Doing me first repository stuff

My name is Zach. I am a second year student in the Anthropology department who is interested in applying cultural hetitage informatics to my interests in paleoethnobotany, Native American culture and life in general.

# SagChip
Sagchip is primarily a testing ground to practice making interesting digital tools for making Anishinaabe culture fun and accessible. I thought it would be interesting to build upon my original repository, where my journey into the digital humanities began.

My first commit begins with a barebones boot strap theme([Start Bootstrap - Bare](https://startbootstrap.com/template/bare/)), and from there it's all experimental. 
